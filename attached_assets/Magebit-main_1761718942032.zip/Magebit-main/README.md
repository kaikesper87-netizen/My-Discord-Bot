# MageBit

MageBit is a Discord RPG bot where players choose elements, battle monsters and other players, collect loot, and level up.

## Quick start

1. Create a private GitHub repo named `MageBit` (you already did).
2. Clone it locally and copy the files.
3. Install dependencies:

```bash
npm install
```

4. Create a `.env` file in the project root (DO NOT commit it) and add the values from `.env.example`.

5. Start the bot:

```bash
npm start
```

6. Invite your bot to a server using the Discord Developer Portal.

## Files
- `src/rpg_bot.js` - main bot implementation
- `index.js` - bootstrap that ensures persistence file exists and starts the bot
- `players.json` - runtime persistence (gitignored)