'use strict';
require('dotenv').config();
const fs = require('fs');
const path = require('path');

const BOT_FILE = path.join(__dirname, 'src', 'rpg_bot.js');
const PLAYERS_FILE = path.join(__dirname, 'players.json');

if (!process.env.TOKEN || !process.env.CLIENT_ID || !process.env.OWNER_ID) {
  console.error('Missing required environment variables. Please create a .env file with TOKEN, CLIENT_ID, OWNER_ID.');
  process.exit(1);
}

if (!fs.existsSync(BOT_FILE)) {
  console.error(`Bot file not found: ${BOT_FILE}`);
  process.exit(1);
}

// ensure players.json exists
if (!fs.existsSync(PLAYERS_FILE)) {
  try { fs.writeFileSync(PLAYERS_FILE, '{}', 'utf8'); console.log('Created players.json'); }
  catch (err) { console.warn('Could not create players.json:', err); }
}

require(BOT_FILE);